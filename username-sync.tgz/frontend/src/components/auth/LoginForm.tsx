"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Icon } from "../Icons";
import { API } from "@/lib/api";

const KEY = "ecopark_admin_token";
// shortcut: token lives in localStorage (simple, survives reloads); move to an httpOnly cookie when the admin UI grows.
const store = {
  get: () => {
    try {
      return localStorage.getItem(KEY);
    } catch {
      return null;
    }
  },
  set: (v: string | null) => {
    try {
      if (v) localStorage.setItem(KEY, v);
      else localStorage.removeItem(KEY);
    } catch {
      /* storage blocked */
    }
  },
};

type Me = { username: string | null; role: string };

function GoogleMark() {
  return (
    <svg viewBox="0 0 48 48" width="18" height="18" aria-hidden>
      <path fill="#FFC107" d="M43.6 20.5H42V20H24v8h11.3C33.7 32.7 29.2 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20 20-8.9 20-20c0-1.3-.1-2.4-.4-3.5z" />
      <path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.7 15.1 19 12 24 12c3.1 0 5.8 1.2 7.9 3.1l5.7-5.7C34 6.1 29.3 4 24 4 16.3 4 9.7 8.3 6.3 14.7z" />
      <path fill="#4CAF50" d="M24 44c5.2 0 9.9-2 13.4-5.2l-6.2-5.2C29.2 35.1 26.7 36 24 36c-5.2 0-9.6-3.3-11.3-8l-6.5 5C9.5 39.6 16.2 44 24 44z" />
      <path fill="#1976D2" d="M43.6 20.5H42V20H24v8h11.3c-.8 2.2-2.2 4.2-4.1 5.6l6.2 5.2C37 39.2 44 34 44 24c0-1.3-.1-2.4-.4-3.5z" />
    </svg>
  );
}

/** Login card: username + password, or continue with Google / Facebook (handled by the API's OAuth redirect). */
export default function LoginForm() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [me, setMe] = useState<Me | null>(null);

  async function loadMe(token: string) {
    const res = await fetch(`${API}/auth/me`, { headers: { Authorization: `Bearer ${token}` } }).catch(() => null);
    if (res?.ok) setMe(await res.json());
    else store.set(null);
  }

  useEffect(() => {
    // Back from Google/Facebook: the API puts #token=… or #error=… in the URL fragment.
    const hash = new URLSearchParams(window.location.hash.slice(1));
    if (hash.has("token") || hash.has("error")) history.replaceState(null, "", window.location.pathname);
    if (hash.get("error")) setError(hash.get("error")!);
    const token = hash.get("token") ?? store.get();
    if (hash.get("token")) store.set(token);
    if (token) loadMe(token);
  }, []);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    setBusy(true);
    setError("");
    try {
      const res = await fetch(`${API}/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: String(f.get("username")).trim(), password: String(f.get("password")) }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(typeof body.message === "string" ? body.message : "Đăng nhập không thành công");
      store.set(body.accessToken);
      setMe(body.user);
    } catch (err) {
      setError(err instanceof TypeError ? "Không kết nối được máy chủ" : (err as Error).message);
    } finally {
      setBusy(false);
    }
  }

  if (me)
    return (
      <div className="flex flex-col gap-5">
        <div className="flex size-14 items-center justify-center rounded-full bg-[#E8F3EC] text-verified">
          <Icon name="check" size={26} />
        </div>
        <div>
          <h1 className="text-[28px] font-extrabold text-esp">Xin chào!</h1>
          <p className="mt-1 text-[14px] text-muted">
            Đã đăng nhập: <b className="text-esp">{me.username}</b> · {me.role === "admin" ? "Quản trị viên" : "Biên tập viên"}
          </p>
        </div>
        <button
          onClick={() => {
            store.set(null);
            setMe(null);
          }}
          className="btn border border-esp text-esp hover:bg-cream"
        >
          ĐĂNG XUẤT
        </button>
      </div>
    );

  const input = "h-12 w-full rounded border border-line bg-white px-4 text-[14px] text-ink placeholder:text-soft focus:border-gold focus:outline-none focus:ring-2 focus:ring-gold/20";
  const social = "flex h-12 w-full items-center justify-center gap-3 rounded border text-[14px] font-semibold transition";
  return (
    <div className="flex flex-col gap-7">
      <div className="flex flex-col gap-2">
        <p className="eyebrow">Khu vực quản trị</p>
        <h1 className="text-[32px] font-extrabold leading-tight text-esp">Đăng nhập</h1>
        <p className="text-[14px] text-muted">Quản lý căn hộ, dự án, slider và khách hàng để lại thông tin.</p>
      </div>

      {error && (
        <p role="alert" className="rounded border border-price/30 bg-price/5 px-4 py-3 text-[13px] text-price">
          {error}
        </p>
      )}

      <form onSubmit={onSubmit} className="flex flex-col gap-4">
        <label className="flex flex-col gap-1.5 text-[13px] font-semibold text-esp">
          Tên đăng nhập
          <input name="username" required autoComplete="username" autoCapitalize="none" spellCheck={false} placeholder="vd: tuan" className={`${input} font-normal`} />
        </label>
        <label className="flex flex-col gap-1.5 text-[13px] font-semibold text-esp">
          Mật khẩu
          <span className="relative">
            <input name="password" type={showPw ? "text" : "password"} required autoComplete="current-password" placeholder="••••••••" className={`${input} pr-16 font-normal`} />
            <button type="button" onClick={() => setShowPw((v) => !v)} className="absolute inset-y-0 right-3 text-[12px] font-semibold text-gold" aria-pressed={showPw}>
              {showPw ? "Ẩn" : "Hiện"}
            </button>
          </span>
        </label>
        <button disabled={busy} className="btn-dark h-12 justify-center disabled:opacity-60">
          {busy ? "ĐANG ĐĂNG NHẬP…" : "ĐĂNG NHẬP"}
        </button>
      </form>

      <div className="flex items-center gap-3 text-[12px] text-soft">
        <span className="h-px flex-1 bg-lineL" /> hoặc <span className="h-px flex-1 bg-lineL" />
      </div>

      <div className="flex flex-col gap-3">
        <a href={`${API}/auth/oauth/google`} className={`${social} border-line bg-white text-ink hover:bg-cream`}>
          <GoogleMark /> Tiếp tục với Google
        </a>
        <a href={`${API}/auth/oauth/facebook`} className={`${social} border-[#1877F2] bg-[#1877F2] text-white hover:brightness-110`}>
          <Icon name="facebook" size={18} /> Tiếp tục với Facebook
        </a>
      </div>

      <p className="text-[12px] leading-relaxed text-soft">Google / Facebook chỉ vào được khi email đó đã được quản trị viên gắn vào tài khoản.</p>
    </div>
  );
}
