# Nguyễn Hồng Tuấn – Ecopark Real Estate

| Thư mục | Stack | Cổng |
|---|---|---|
| `frontend/` | Next.js 14 (App Router) + Tailwind, font Manrope | 3000 |
| `backend/` | NestJS 10 + TypeORM + PostgreSQL 16 | 4000 |

## Chạy local

```bash
docker compose up -d                 # PostgreSQL
cd backend  && cp .env.example .env && npm i && npm run build && npm run seed && npm start
cd frontend && cp .env.example .env.local && npm i && npm run dev
```

Backend đọc biến môi trường từ shell (chưa nạp `.env` tự động) — export trước khi chạy, ví dụ `set -a; . ./.env; set +a`.
Frontend vẫn chạy được khi API tắt: tự dùng dữ liệu mẫu `frontend/src/data/seed.json`.

## Trang

| URL | Nội dung |
|---|---|
| `/`, `/en` | Trang chủ VI / EN |
| `/properties/for-rent` · `resale` · `projects` | Danh sách + bộ lọc (lưu trên URL) |
| `/property/[code]` | Chi tiết căn + đặt lịch xem |
| `/projects/[slug]` | Dự án: Thông tin → Bản đồ → Chính sách → Hàng dự án |
| `/about`, `/ecopark` | Giới thiệu |

## API (`/api`)

| Method | Path | |
|---|---|---|
| GET | `/properties?type=rent\|resale\|project`, `/properties/:code` | |
| GET | `/projects/:slug`, `/slides`, `/videos`, `/testimonials` | |
| POST | `/leads` | form liên hệ / đặt lịch (có validate) |
| POST | `/auth/login` | `{ username, password }` → `{ accessToken }` (JWT, mặc định 8h). Sai 5 lần → khoá 15 phút |
| GET | `/auth/oauth/google`, `/auth/oauth/facebook` | Tiếp tục với Google / Facebook — email phải được admin gắn vào một tài khoản |
| GET | `/auth/me` | thông tin người đang đăng nhập |
| POST | `/auth/users` | *(admin)* tạo tài khoản `{ username, password, role: "admin" \| "editor", email? }` — `email` chỉ để dùng Google/Facebook |
| GET/POST/PUT/DELETE | `/admin/:resource[/:id]` | `Authorization: Bearer <accessToken>`; resource = properties, projects, slides, videos, testimonials, leads |

| Role | Quyền |
|---|---|
| `admin` | Toàn bộ, gồm khách hàng (leads) và tạo tài khoản |
| `editor` | Chỉ nội dung: căn, dự án, slider, video, đánh giá |

Màn đăng nhập: `http://localhost:3000/login`. Tài khoản admin đầu tiên tạo bằng `npm run seed` từ `ADMIN_USERNAME` / `ADMIN_PASSWORD` (và `ADMIN_EMAIL` nếu muốn đăng nhập Google/Facebook) trong `.env`.

Ví dụ đổi thứ tự slider "Dự án đang mở bán" (lấy token từ `/auth/login`):
`curl -X PUT -H "Authorization: Bearer $TOKEN" -H "Content-Type: application/json" -d '{"sortOrder":1}' localhost:4000/api/admin/slides/2`

Web cập nhật sau tối đa 60 giây (ISR).

Smoke test: chạy API rồi `cd backend && npm test`.

## Cần thay trước khi lên production

- Ảnh bàn giao thật → `frontend/public/images/clients/client-1..4.webp` (đang là ảnh tạm)
- SĐT, email, Zalo, Facebook, YouTube → `frontend/.env.local`
- `embedId` video TikTok/YouTube thật, số liệu trang Về tôi, toạ độ phân khu trên bản đồ Về Ecopark
- Thông tin Eco Retreat (đang tổng hợp từ báo chí) – cần anh Tuấn xác nhận
