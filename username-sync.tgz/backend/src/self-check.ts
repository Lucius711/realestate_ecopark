// Smoke test against a running API: `npm run dev` (or start) in one shell, `npm test` in another.
import assert from "assert";

try {
  process.loadEnvFile(); // reuse ADMIN_EMAIL / ADMIN_PASSWORD from backend/.env
} catch {
  /* no .env */
}

const API = process.env.API_URL ?? "http://localhost:4000/api";
const post = (path: string, body: unknown, headers: Record<string, string> = {}) =>
  fetch(API + path, { method: "POST", headers: { "Content-Type": "application/json", ...headers }, body: JSON.stringify(body) });

(async () => {
  const rent = await (await fetch(`${API}/properties?type=rent`)).json();
  assert(Array.isArray(rent) && rent.every((p: { type: string }) => p.type === "rent"), "type filter");
  assert.equal((await fetch(`${API}/properties/NOPE`)).status, 404);
  assert.equal((await fetch(`${API}/projects/eco-retreat`)).status, 200);
  assert.equal((await post("/leads", { name: "A", phone: "abc", source: "footer" })).status, 400, "bad phone rejected");
  assert.equal((await post("/leads", { name: "A", phone: "0912345678", source: "footer", isAdmin: true })).status, 400, "unknown field rejected");
  assert.equal((await post("/leads", { name: "Test", phone: "0912 345 678", email: "", source: "detail", propertyCode: "ECO-1801" })).status, 201);
  // --- auth ---
  const get = (path: string, token?: string) => fetch(API + path, { headers: token ? { Authorization: `Bearer ${token}` } : {} });
  assert.equal((await get("/admin/leads")).status, 401, "admin needs a token");
  assert.equal((await get("/admin/leads", "not.a.jwt")).status, 401, "garbage token rejected");

  const { ADMIN_USERNAME, ADMIN_PASSWORD } = process.env;
  assert(ADMIN_USERNAME && ADMIN_PASSWORD, "set ADMIN_USERNAME / ADMIN_PASSWORD and run `npm run seed` first");
  const login = async (username: string, password: string) => post("/auth/login", { username, password });

  const ok = await login(ADMIN_USERNAME, ADMIN_PASSWORD);
  assert.equal(ok.status, 200, "admin login");
  const admin = (await ok.json()).accessToken as string;
  assert.equal((await get("/admin/leads", admin)).status, 200, "admin reads leads");
  assert.equal((await get("/auth/me", admin)).status, 200);

  // editor: content yes, leads / creating users no
  const editorName = `editor${Date.now()}`;
  assert.equal((await post("/auth/users", { username: editorName, password: "editor-pass-123", role: "editor" }, { Authorization: `Bearer ${admin}` })).status, 201);
  const editor = (await (await login(editorName, "editor-pass-123")).json()).accessToken as string;
  assert.equal((await get("/admin/slides", editor)).status, 200, "editor manages content");
  assert.equal((await get("/admin/leads", editor)).status, 403, "editor cannot read leads");
  assert.equal((await post("/auth/users", { username: "hacker", password: "xxxxxxxxxxxx", role: "admin" }, { Authorization: `Bearer ${editor}` })).status, 403, "editor cannot create users");

  assert.equal((await post("/auth/users", { username: editorName, password: "another-pass-1", role: "editor" }, { Authorization: `Bearer ${admin}` })).status, 409, "duplicate username");
  assert.equal((await login(editorName.toUpperCase(), "editor-pass-123")).status, 200, "username is case-insensitive");

  // lockout after 5 wrong passwords
  for (let i = 0; i < 5; i++) assert.equal((await login(editorName, "wrong-password")).status, 401);
  assert.equal((await login(editorName, "editor-pass-123")).status, 429, "locked after 5 failures");
  console.log("self-check ok");
})().catch((e) => {
  console.error(e);
  process.exit(1);
});
