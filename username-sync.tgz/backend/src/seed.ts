import "reflect-metadata";
import { DataSource } from "typeorm";
import { dbOptions } from "./main";
import { Project, Property, Slide, Testimonial, User, Video } from "./entities";
import { hashPassword } from "./auth";
import { readFileSync } from "fs";
import { resolve } from "path";

const SEED = process.env.SEED_FILE ?? resolve(__dirname, "../../frontend/src/data/seed.json");

/** Loads the same sample data the frontend falls back to. Upserts, so it is safe to re-run. */
async function run() {
  const db = await new DataSource({ ...dbOptions, synchronize: true }).initialize();
  const s = JSON.parse(readFileSync(SEED, "utf8")) as Record<string, Record<string, unknown>[]>;
  await db.getRepository(Property).save(s.properties as never);
  await db.getRepository(Project).save(s.projects as never);
  await db.getRepository(Slide).save(s.slides as never);
  await db.getRepository(Video).save(s.videos as never);
  await db.getRepository(Testimonial).save(s.testimonials as never);
  for (const t of ["slides", "videos", "testimonials"]) await db.query(`SELECT setval(pg_get_serial_sequence('${t}','id'), (SELECT COALESCE(MAX(id),1) FROM ${t}))`);
  // First admin. ADMIN_EMAIL is optional: set it to also allow "Tiếp tục với Google / Facebook" with that address.
  const username = process.env.ADMIN_USERNAME?.toLowerCase();
  const pw = process.env.ADMIN_PASSWORD;
  if (username && pw) {
    if (pw.length < 10) throw new Error("ADMIN_PASSWORD must be at least 10 characters");
    const users = db.getRepository(User);
    if (!(await users.findOneBy({ username }))) {
      await users.save(users.create({ username, email: process.env.ADMIN_EMAIL?.toLowerCase() || null, passwordHash: await hashPassword(pw), role: "admin" }));
      console.log(`Created admin "${username}"`);
    }
  }
  console.log("Seeded:", Object.entries(s).map(([k, v]) => `${k}=${v.length}`).join(" "));
  await db.destroy();
}

run().catch((e) => {
  console.error(e);
  process.exit(1);
});
