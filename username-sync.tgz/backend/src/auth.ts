import {
  Body,
  CanActivate,
  ConflictException,
  Controller,
  ExecutionContext,
  Get,
  HttpCode,
  HttpException,
  Injectable,
  Post,
  Req,
  SetMetadata,
  UnauthorizedException,
  ForbiddenException,
  UseGuards,
} from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { JwtService } from "@nestjs/jwt";
import { InjectRepository } from "@nestjs/typeorm";
import { IsEmail, IsIn, IsOptional, IsString, Length, Matches } from "class-validator";
import { randomBytes, scrypt, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { Repository } from "typeorm";
import { ROLES, User, type Role } from "./entities";

const scryptAsync = promisify(scrypt) as (pw: string, salt: Buffer, len: number) => Promise<Buffer>;

/** "scrypt$<salt hex>$<hash hex>" — node's built-in scrypt, no native bcrypt build needed on Windows. */
export async function hashPassword(pw: string) {
  const salt = randomBytes(16);
  return `scrypt$${salt.toString("hex")}$${(await scryptAsync(pw, salt, 64)).toString("hex")}`;
}

export async function verifyPassword(pw: string, stored: string | null) {
  const [algo, salt, hash] = (stored ?? "").split("$");
  if (algo !== "scrypt" || !salt || !hash) return false;
  const got = await scryptAsync(pw, Buffer.from(salt, "hex"), 64);
  return timingSafeEqual(got, Buffer.from(hash, "hex"));
}

export interface JwtUser {
  sub: number;
  username: string | null;
  role: Role;
}

export const tokenPayload = (u: User): JwtUser => ({ sub: u.id, username: u.username, role: u.role });

const USERNAME = /^[a-zA-Z0-9._-]{3,32}$/;

/** Endpoints guarded by JwtGuard may restrict further with @Roles("admin"). No @Roles = any logged-in user. */
export const Roles = (...roles: Role[]) => SetMetadata("roles", roles);

@Injectable()
export class JwtGuard implements CanActivate {
  constructor(
    private jwt: JwtService,
    private reflector: Reflector,
  ) {}

  async canActivate(ctx: ExecutionContext) {
    const req = ctx.switchToHttp().getRequest();
    const token = /^Bearer (.+)$/.exec(String(req.headers.authorization ?? ""))?.[1];
    if (!token) throw new UnauthorizedException();
    try {
      req.user = await this.jwt.verifyAsync<JwtUser>(token);
    } catch {
      throw new UnauthorizedException("Token không hợp lệ hoặc đã hết hạn");
    }
    const roles = this.reflector.getAllAndOverride<Role[] | undefined>("roles", [ctx.getHandler(), ctx.getClass()]);
    if (roles && !roles.includes(req.user.role)) throw new ForbiddenException();
    return true;
  }
}

export class LoginDto {
  @IsString() @Length(1, 64) username: string;
  @IsString() @Length(1, 200) password: string;
}

export class CreateUserDto {
  @Matches(USERNAME, { message: "username: 3–32 ký tự, chỉ chữ, số, . _ -" }) username: string;
  /** Optional: lets this account also use "Tiếp tục với Google / Facebook". */
  @IsOptional() @IsEmail() email?: string;
  @IsString() @Length(10, 200) password: string;
  @IsIn(ROLES) role: Role;
}

// shortcut: in-memory lockout resets on restart and is per-process; move to Redis if the API runs on several instances.
const failures = new Map<string, { count: number; until: number }>();
const MAX_FAILS = 5;
const LOCK_MS = 15 * 60 * 1000;

@Controller("auth")
export class AuthController {
  constructor(
    @InjectRepository(User) private users: Repository<User>,
    private jwt: JwtService,
  ) {}

  @Post("login")
  @HttpCode(200)
  async login(@Body() dto: LoginDto) {
    const username = dto.username.trim().toLowerCase();
    const f = failures.get(username);
    if (f && f.count >= MAX_FAILS && f.until > Date.now()) throw new HttpException("Đăng nhập sai quá nhiều lần, thử lại sau 15 phút", 429);

    const user = await this.users.findOneBy({ username });
    if (!user || !(await verifyPassword(dto.password, user.passwordHash))) {
      const next = f && f.until > Date.now() ? f.count + 1 : 1;
      failures.set(username, { count: next, until: Date.now() + LOCK_MS });
      throw new UnauthorizedException("Sai tên đăng nhập hoặc mật khẩu");
    }
    failures.delete(username);
    return { accessToken: await this.jwt.signAsync(tokenPayload(user)), user: { username: user.username, role: user.role } };
  }

  @Get("me")
  @UseGuards(JwtGuard)
  me(@Req() req: { user: JwtUser }) {
    return req.user;
  }

  /** Admin adds another account (e.g. an editor who only manages listings). */
  @Post("users")
  @UseGuards(JwtGuard)
  @Roles("admin")
  async createUser(@Body() dto: CreateUserDto) {
    const username = dto.username.toLowerCase();
    const email = dto.email?.toLowerCase() ?? null;
    if (await this.users.findOneBy({ username })) throw new ConflictException("Tên đăng nhập đã tồn tại");
    if (email && (await this.users.findOneBy({ email }))) throw new ConflictException("Email đã gắn với tài khoản khác");
    const u = await this.users.save(this.users.create({ username, email, passwordHash: await hashPassword(dto.password), role: dto.role }));
    return { id: u.id, username: u.username, email: u.email, role: u.role };
  }
}
