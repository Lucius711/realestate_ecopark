import { Column, CreateDateColumn, Entity, Index, PrimaryColumn, PrimaryGeneratedColumn } from "typeorm";

// Shapes mirror frontend/src/lib/types.ts — keep both in sync.

@Entity("properties")
export class Property {
  @PrimaryColumn() code: string;
  @Index() @Column() type: "rent" | "resale" | "project";
  @Column() title: string;
  @Column() priceLabel: string;
  @Column("numeric", { transformer: { to: (v: number) => v, from: (v: string) => Number(v) } }) priceMillion: number;
  @Column() district: string;
  @Column("int", { nullable: true }) bedrooms: number | null;
  @Column("int", { nullable: true }) bathrooms: number | null;
  @Column("real") areaM2: number;
  @Column({ default: false }) landArea: boolean;
  @Column({ default: "" }) floorLabel: string;
  @Column("jsonb", { default: [] }) images: string[];
  @Column({ default: false }) hasVideo: boolean;
  @Column({ default: false }) verified: boolean;
  @Column("text", { default: "" }) description: string;
  @Column("varchar", { nullable: true }) direction: string | null;
  @Column("varchar", { nullable: true }) furniture: string | null;
  @Column("varchar", { nullable: true }) legal: string | null;
  @Index() @Column("varchar", { nullable: true }) projectSlug: string | null;
  @Column({ default: true }) published: boolean;
  @Column("timestamptz", { default: () => "now()" }) postedAt: Date;
}

@Entity("projects")
export class Project {
  @PrimaryColumn() slug: string;
  @Column() name: string;
  @Column() location: string;
  @Column() address: string;
  @Column("real") areaHa: number;
  @Column("text") summary: string;
  @Column("text") overview: string;
  @Column({ default: "" }) tagline: string;
  @Column() heroImage: string;
  @Column({ default: "" }) overviewImage: string;
  @Column("jsonb", { default: [] }) facts: { value: string; label: string }[];
  @Column("jsonb", { default: [] }) productTypes: { name: string; description: string; image: string }[];
  @Column("jsonb", { default: [] }) amenities: string[];
  @Column("jsonb", { default: [] }) policies: { title: string; detail: string }[];
  @Column() mapQuery: string;
  @Column("text", { default: "" }) sourceNote: string;
}

/** "Dự án đang mở bán" homepage slider — admin edits these. */
@Entity("slides")
export class Slide {
  @PrimaryGeneratedColumn() id: number;
  @Column() title: string;
  @Column() location: string;
  @Column("text") description: string;
  @Column() image: string;
  @Column() link: string;
  @Column("int", { default: 0 }) sortOrder: number;
  @Column({ default: true }) active: boolean;
}

@Entity("videos")
export class Video {
  @PrimaryGeneratedColumn() id: number;
  @Column() platform: "tiktok" | "youtube";
  @Column() title: string;
  @Column() url: string;
  @Column("varchar", { nullable: true }) embedId: string | null;
  @Column() thumbnail: string;
  @Column({ default: "" }) views: string;
  @Column("varchar", { nullable: true }) duration: string | null;
  @Column({ default: false }) featured: boolean;
}

@Entity("testimonials")
export class Testimonial {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
  @Column() deal: string;
  @Column("text") quote: string;
  @Column("varchar", { nullable: true }) avatar: string | null;
  @Column("int", { default: 5 }) rating: number;
}

/** Contact / viewing requests from the site forms. */
@Entity("leads")
export class Lead {
  @PrimaryGeneratedColumn() id: number;
  @Column() name: string;
  @Column() phone: string;
  @Column("varchar", { nullable: true }) email: string | null;
  @Column("text", { nullable: true }) message: string | null;
  @Column() source: string;
  @Column("varchar", { nullable: true }) propertyCode: string | null;
  @Column({ default: "new" }) status: string;
  @CreateDateColumn({ type: "timestamptz" }) createdAt: Date;
}

/** admin: everything incl. leads + accounts; editor: content only (listings, projects, slides, videos, testimonials). */
export const ROLES = ["admin", "editor"] as const;
export type Role = (typeof ROLES)[number];

@Entity("users")
export class User {
  @PrimaryGeneratedColumn() id: number;
  /** Login name for username + password sign-in (stored lowercase). */
  @Index({ unique: true }) @Column("varchar", { nullable: true }) username: string | null;
  /** Only used to match "Tiếp tục với Google / Facebook"; optional. */
  @Index({ unique: true }) @Column("varchar", { nullable: true }) email: string | null;
  @Column("varchar", { nullable: true }) passwordHash: string | null;
  @Column({ default: "editor" }) role: Role;
  @CreateDateColumn({ type: "timestamptz" }) createdAt: Date;
}

export const ENTITIES = [Property, Project, Slide, Video, Testimonial, Lead, User];
